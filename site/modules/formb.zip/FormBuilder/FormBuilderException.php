<?php

/**
 * ProcessWire Form Builder Exception
 *
 * Copyright (C) 2012 by Ryan Cramer Design, LLC
 * 
 * PLEASE DO NOT DISTRIBUTE
 * 
 */

class FormBuilderException extends Exception { }

